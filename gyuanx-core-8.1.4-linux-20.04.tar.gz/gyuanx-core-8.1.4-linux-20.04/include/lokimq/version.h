namespace lokimq {
constexpr int VERSION_MAJOR = 1;
constexpr int VERSION_MINOR = 2;
constexpr int VERSION_PATCH = 1;
}
